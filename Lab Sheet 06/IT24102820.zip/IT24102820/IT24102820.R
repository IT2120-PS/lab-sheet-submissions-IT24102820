setwd("C:\\Users\\C TECH\\OneDrive - Sri Lanka Institute of Information Technology\\Desktop\\IT24102820")
getwd()
#1)
#i.Bionomial distribution
#ii.
1-pbinom(46,50,0.85,lower.tail=TRUE)


#2)
#i. Number of calls per hour.
#ii. Poisson distribution
#iii.
dpois(15,20)


